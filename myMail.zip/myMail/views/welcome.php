<div class="wrap about-wrap">

	<h1>Welcome to MyMail 1.0.0</h1>

	<div class="about-text">
		Easily create, send and track your Newsletter Campaigns<br>

	</div>


<?php if(!mymail_option('purchasecode')): ?>
	<!--<div class="license">
		<?php if(isset($_POST['purchasecode']) && !empty($_POST['purchasecode'])):
			mymail_update_option('purchasecode', esc_attr($_POST['purchasecode']));
		?>
		<h3>Thanks, your license code has been saved!</h3>
		<?php else : ?>
		<h3>Enable Automatic Updates by providing your License Code.</h3>
		<p class="description">MyMail can get updated automatically so you can always work with the latest version and its features.</p>
		<form action="edit.php?post_type=newsletter&page=mymail_welcome" method="POST">
			<input type="text" class="widefat purchasecode" placeholder="XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX" name="purchasecode" required pattern="[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}" autocomplete="off" maxlength="36">
			<input type="submit" class="button button-primary" value="Save">
		</form>
		<?php endif; ?>
	</div>-->
<?php endif; ?>
<?php
if ( get_transient( '_mymail_translation' ) ) :
	$url = add_query_arg(array(
		'action' => 'do-translation-upgrade',
		'_wpnonce' => wp_create_nonce( 'upgrade-translations' ),
	), admin_url( 'update-core.php' ));
	?>
	<!--<div class="update-nag"><p><strong><?php _e('MyMail is available in your language.', 'mymail') ?></strong> <a class="button button-primary button-small" href="<?php echo esc_url($url) ?>"><?php _e('load it now', 'mymail'); ?></a></p></div>-->
	<?php
endif;
?>

		<div class="changelog">
			<div class="feature-section under-the-hood three-col">
				<div class="col">
					<h4>Honeypots for Forms</h4>
					<p>Forms have now an additional spam prevention with a honeypot.</p>
				</div>
				<div class="col">
					<h4>Segmentation with regular expressions</h4>
					<p>Segmentation is now even more flexible when using regular expression.</p>
				</div>
				<div class="col">
					<h4>Do-Not-Track feature</h4>
					<p>MyMail can respect you subscribers <a href="http://donottrack.us/">Do-Not-Track</a> settings to respect their privacy. Enable this option on the <a href="options-general.php?page=newsletter-settings#subscribers">settings page</a></p>
				</div>
				<div class="col">
					<h4>Ignoring Posts</h4>
					<p>If you use dynamic post tags you can exclude certain post with a <code>mymail_ignore</code> custom field.</p>
				</div>
				<div class="col">
					<h4>Background images</h4>
					<p>Some background images in templates can now get changed like other images in your campaign.</p>
				</div>
				<div class="col">
					<h4>Single Opt Out</h4>
					<p>Canceling subscription is now faster with a single click. Enable this option on the <a href="options-general.php?page=newsletter-settings#subscribers">settings page</a>.</p>
				</div>
			</div>
			<div class="feature-section under-the-hood three-col">
				<div class="col">
					<h4>Compressed Assets</h4>
					<p>All JavaScript and CSS files are now compressed via YUIcompresser to increase performance.</p>
				</div>
				<div class="col">
					<h4>Bounce Handling for Confirmation</h4>
					<p>If confirmation messages bounce back MyMail can handle them and change the status of the user.</p>
				</div>
			</div>

			<div class="return-to-dashboard">
				<a href="edit.php?post_type=newsletter">Go to Newsletter</a>
			</div>

		</div>

<div class="clear"></div>



<div id="ajax-response"></div>
<br class="clear">
</div>
